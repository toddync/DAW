import { create } from 'zustand'

interface DateRange {
  start: string | null
  end: string | null
}

interface FilterState {
  bedTypes: Set<string>
  amenities: Set<string>
}

interface BookingState {
  dateRange: DateRange
  setDateRange: (start: string | null, end: string | null) => void
  selectedBed: string | null
  setSelectedBed: (bedId: string | null) => void
  isBooking: boolean
  setIsBooking: (isBooking: boolean) => void
  filters: FilterState
  toggleBedType: (type: string) => void
  toggleAmenity: (amenity: string) => void
  clearFilters: () => void
}

export const useBookingStore = create<BookingState>((set) => ({
  dateRange: { start: null, end: null },
  setDateRange: (start, end) => set({ dateRange: { start, end } }),
  selectedBed: null,
  setSelectedBed: (bedId) => set({ selectedBed: bedId }),
  isBooking: false,
  setIsBooking: (isBooking) => set({ isBooking }),
  filters: {
    bedTypes: new Set(),
    amenities: new Set(),
  },
  toggleBedType: (type) =>
    set((state) => {
      const newBedTypes = new Set(state.filters.bedTypes)
      if (newBedTypes.has(type)) {
        newBedTypes.delete(type)
      } else {
        newBedTypes.add(type)
      }
      return {
        filters: { ...state.filters, bedTypes: newBedTypes },
      }
    }),
  toggleAmenity: (amenity) =>
    set((state) => {
      const newAmenities = new Set(state.filters.amenities)
      if (newAmenities.has(amenity)) {
        newAmenities.delete(amenity)
      } else {
        newAmenities.add(amenity)
      }
      return {
        filters: { ...state.filters, amenities: newAmenities },
      }
    }),
  clearFilters: () =>
    set({
      filters: {
        bedTypes: new Set(),
        amenities: new Set(),
      },
    }),
}))
