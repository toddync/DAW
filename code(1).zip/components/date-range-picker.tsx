'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card } from '@/components/ui/card'
import { Calendar } from 'lucide-react'
import { useBookingStore } from '@/lib/store'

export function DateRangePicker() {
  const { dateRange, setDateRange } = useBookingStore()
  const [startInput, setStartInput] = useState(dateRange.start || '')
  const [endInput, setEndInput] = useState(dateRange.end || '')
  const [error, setError] = useState<string | null>(null)

  const handleApply = () => {
    if (!startInput || !endInput) {
      setError('Please select both start and end dates')
      return
    }

    const start = new Date(startInput)
    const end = new Date(endInput)
    const today = new Date()
    today.setHours(0, 0, 0, 0)

    if (start < today) {
      setError('Start date cannot be in the past')
      return
    }

    if (start >= end) {
      setError('Start date must be before end date')
      return
    }

    setDateRange(startInput, endInput)
    setError(null)
  }

  const handleClear = () => {
    setDateRange(null, null)
    setStartInput('')
    setEndInput('')
    setError(null)
  }

  return (
    <Card className="p-6 mb-8 bg-card">
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-foreground flex items-center gap-2">
          <Calendar className="w-5 h-5" />
          Select Your Dates
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">Check-in</label>
            <Input
              type="date"
              value={startInput}
              onChange={(e) => setStartInput(e.target.value)}
              min={new Date().toISOString().split('T')[0]}
              className="w-full"
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">Check-out</label>
            <Input
              type="date"
              value={endInput}
              onChange={(e) => setEndInput(e.target.value)}
              min={startInput || new Date().toISOString().split('T')[0]}
              className="w-full"
            />
          </div>
        </div>

        {error && <div className="text-sm text-destructive">{error}</div>}

        <div className="flex gap-2">
          <Button onClick={handleApply} className="flex-1">
            Search
          </Button>
          <Button onClick={handleClear} variant="outline" className="flex-1">
            Clear
          </Button>
        </div>
      </div>
    </Card>
  )
}
